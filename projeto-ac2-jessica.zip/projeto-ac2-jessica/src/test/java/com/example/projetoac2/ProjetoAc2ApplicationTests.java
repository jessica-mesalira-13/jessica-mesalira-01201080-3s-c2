package com.example.projetoac2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoAc2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
